plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
}

tasks.register("assembleDebug") {
    dependsOn(":app:assembleDebug")
}
tasks.register("assembleRelease") {
    dependsOn(":app:assembleRelease")
}
